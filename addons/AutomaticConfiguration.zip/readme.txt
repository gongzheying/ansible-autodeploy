1. Introduction about automatically configuration tool of IBSPs system.
   This tool is desiged to facilitate DPC to deploy IBSPs java application program. 
   When one DPC get IBSPs compiled program packages from ITS, configurations related with system environment in these program packages are not matched with DPC production system.
   So DPC can use this tool to replace environment's configurations with DPC actual system parameters.


2. How to use configuration subtitute tool
	1) Pre-conditions: JDK 1.6 or higher version must be installed in your computer

	2) Modify IBSPs configuration.xml as Parameter specification file ��ParametersSpecification.docx��.

	3) Copy deployment *.ear files(including seurat-web-ci.ear, job-schedule-ci.ear, job-execution-ci.ear) into earSourceFiles folder.
	
	For windows OS: if you use windows OS, then operate as step 4-1
	4-1)	Open windows cmd.exe and execute cd command to the folder that configuration.xml stored in(such as %parentPath%/configurationManage).
			cd %parentPath%/configurationManage
      then execute bat file in cmd window: 
			conf.bat

	For linux OS: if you use Linux OS, then operate as step 4-2, and conf.sh is still programming, so until now you only can use windows' version
	4-2) execute cd command to the folder that configuration.xml stored in(such as %parentPath%/configurationManage).
		 cd %parentPath%/configurationManage
     then execute bash file: 
		 /sbin/bash conf.sh

	5)	after conf.bat or conf.sh file execute successfully, the deployed package will be generated into %parentPath% / configurationManage/earFiles folder.
