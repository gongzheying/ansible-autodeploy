#!/bin/sh
current_path=`pwd`

if [ -e seurat-web-ci.ear ]
then 
rm -rf seurat-web-ci.ear 
fi

if [ -e job-schedule-ci.ear ]
then 
rm -rf job-schedule-ci.ear 
fi

if [ -e job-execution-ci.ear ]
then 
rm -rf job-execution-ci.ear 
fi

mkdir seurat-web-ci.ear
mkdir job-schedule-ci.ear
mkdir job-execution-ci.ear

cp ./earSourceFiles/seurat-web-ci.ear ./seurat-web-ci.ear/
cp ./earSourceFiles/job-schedule-ci.ear ./job-schedule-ci.ear/
cp ./earSourceFiles/job-execution-ci.ear ./job-execution-ci.ear

#----------------------------------web----------------------------------------------
cd $current_path/seurat-web-ci.ear
jar -xf seurat-web-ci.ear
rm --force seurat-web-ci.ear

mkdir temp
cd temp
mkdir seurat-web.war
mkdir domainmodel-project-1.0.0-SNAPSHOT.jar
mkdir ios-utilities-1.0.0-SNAPSHOT.jar
mkdir seurat-automation-1.0.0-SNAPSHOT.jar
mkdir seurat-initialize-3.3.0-SNAPSHOT.jar
mkdir seurat-report-1.0.0-SNAPSHOT.jar

cp $current_path/seurat-web-ci.ear/seurat-web.war $current_path/seurat-web-ci.ear/temp/seurat-web.war
cp $current_path/seurat-web-ci.ear/lib/domainmodel-project-1.0.0-SNAPSHOT.jar  $current_path/seurat-web-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
cp $current_path/seurat-web-ci.ear/lib/ios-utilities-1.0.0-SNAPSHOT.jar  $current_path/seurat-web-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
cp $current_path/seurat-web-ci.ear/lib/seurat-automation-1.0.0-SNAPSHOT.jar  $current_path/seurat-web-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
cp $current_path/seurat-web-ci.ear/lib/seurat-initialize-3.3.0-SNAPSHOT.jar  $current_path/seurat-web-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
cp $current_path/seurat-web-ci.ear/lib/seurat-report-1.0.0-SNAPSHOT.jar  $current_path/seurat-web-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar

cd $current_path/seurat-web-ci.ear/temp/seurat-web.war
jar -xf seurat-web.war
rm -f seurat-web.war

cd $current_path/seurat-web-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
jar -xf domainmodel-project-1.0.0-SNAPSHOT.jar
rm --force domainmodel-project-1.0.0-SNAPSHOT.jar

cd $current_path/seurat-web-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
jar -xf ios-utilities-1.0.0-SNAPSHOT.jar
rm --force ios-utilities-1.0.0-SNAPSHOT.jar

cd $current_path/seurat-web-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
jar -xf seurat-automation-1.0.0-SNAPSHOT.jar
rm --force seurat-automation-1.0.0-SNAPSHOT.jar

cd $current_path/seurat-web-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
jar -xf seurat-initialize-3.3.0-SNAPSHOT.jar
rm --force seurat-initialize-3.3.0-SNAPSHOT.jar

cd $current_path/seurat-web-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar
jar -xf seurat-report-1.0.0-SNAPSHOT.jar
rm --force seurat-report-1.0.0-SNAPSHOT.jar

#-----------------------------schedule----------------------------------------------
cd $current_path/job-schedule-ci.ear
jar -xf job-schedule-ci.ear
rm --force job-schedule-ci.ear

mkdir temp
cd $current_path/job-schedule-ci.ear/temp
mkdir job-schedule.war
mkdir domainmodel-project-1.0.0-SNAPSHOT.jar
mkdir ios-utilities-1.0.0-SNAPSHOT.jar
mkdir seurat-automation-1.0.0-SNAPSHOT.jar
mkdir seurat-initialize-3.3.0-SNAPSHOT.jar
mkdir seurat-report-1.0.0-SNAPSHOT.jar

cp $current_path/job-schedule-ci.ear/job-schedule.war $current_path/job-schedule-ci.ear/temp/job-schedule.war
cp $current_path/job-schedule-ci.ear/lib/domainmodel-project-1.0.0-SNAPSHOT.jar  $current_path/job-schedule-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
cp $current_path/job-schedule-ci.ear/lib/ios-utilities-1.0.0-SNAPSHOT.jar  $current_path/job-schedule-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
cp $current_path/job-schedule-ci.ear/lib/seurat-automation-1.0.0-SNAPSHOT.jar  $current_path/job-schedule-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
cp $current_path/job-schedule-ci.ear/lib/seurat-initialize-3.3.0-SNAPSHOT.jar  $current_path/job-schedule-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
cp $current_path/job-schedule-ci.ear/lib/seurat-report-1.0.0-SNAPSHOT.jar  $current_path/job-schedule-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar

cd $current_path/job-schedule-ci.ear/temp/job-schedule.war
jar -xf job-schedule.war
rm --force job-schedule.war

cd $current_path/job-schedule-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
jar -xf domainmodel-project-1.0.0-SNAPSHOT.jar
rm --force domainmodel-project-1.0.0-SNAPSHOT.jar

cd $current_path/job-schedule-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
jar -xf ios-utilities-1.0.0-SNAPSHOT.jar
rm --force ios-utilities-1.0.0-SNAPSHOT.jar

cd $current_path/job-schedule-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
jar -xf seurat-automation-1.0.0-SNAPSHOT.jar
rm --force seurat-automation-1.0.0-SNAPSHOT.jar

cd $current_path/job-schedule-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
jar -xf seurat-initialize-3.3.0-SNAPSHOT.jar
rm --force seurat-initialize-3.3.0-SNAPSHOT.jar

cd $current_path/job-schedule-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar
jar -xf seurat-report-1.0.0-SNAPSHOT.jar
rm --force seurat-report-1.0.0-SNAPSHOT.jar

#-----------------------------exection----------------------------------------------
cd $current_path/job-execution-ci.ear
jar -xf job-execution-ci.ear
rm --force job-execution-ci.ear

mkdir temp
cd $current_path/job-execution-ci.ear/temp
mkdir job-execution.war
mkdir domainmodel-project-1.0.0-SNAPSHOT.jar
mkdir ios-utilities-1.0.0-SNAPSHOT.jar
mkdir seurat-automation-1.0.0-SNAPSHOT.jar
mkdir seurat-initialize-3.3.0-SNAPSHOT.jar
mkdir seurat-report-1.0.0-SNAPSHOT.jar

cp $current_path/job-execution-ci.ear/job-execution.war $current_path/job-execution-ci.ear/temp/job-execution.war
cp $current_path/job-execution-ci.ear/lib/domainmodel-project-1.0.0-SNAPSHOT.jar  $current_path/job-execution-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
cp $current_path/job-execution-ci.ear/lib/ios-utilities-1.0.0-SNAPSHOT.jar  $current_path/job-execution-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
cp $current_path/job-execution-ci.ear/lib/seurat-automation-1.0.0-SNAPSHOT.jar  $current_path/job-execution-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
cp $current_path/job-execution-ci.ear/lib/seurat-initialize-3.3.0-SNAPSHOT.jar  $current_path/job-execution-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
cp $current_path/job-execution-ci.ear/lib/seurat-report-1.0.0-SNAPSHOT.jar  $current_path/job-execution-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar

cd $current_path/job-execution-ci.ear/temp/job-execution.war
jar -xf job-execution.war
rm --force job-execution.war

cd $current_path/job-execution-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
jar -xf domainmodel-project-1.0.0-SNAPSHOT.jar
rm --force domainmodel-project-1.0.0-SNAPSHOT.jar

cd $current_path/job-execution-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
jar -xf ios-utilities-1.0.0-SNAPSHOT.jar
rm --force ios-utilities-1.0.0-SNAPSHOT.jar

cd $current_path/job-execution-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
jar -xf seurat-automation-1.0.0-SNAPSHOT.jar
rm --force seurat-automation-1.0.0-SNAPSHOT.jar

cd $current_path/job-execution-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
jar -xf seurat-initialize-3.3.0-SNAPSHOT.jar
rm --force seurat-initialize-3.3.0-SNAPSHOT.jar

cd $current_path/job-execution-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar
jar -xf seurat-report-1.0.0-SNAPSHOT.jar
rm --force seurat-report-1.0.0-SNAPSHOT.jar


#execute substitute java program
cd $current_path
java -jar IBSPsConfiguration.jar $current_path

#jar folder to war or jar file
#----------------------------web-----------------------------------------
cd $current_path/seurat-web-ci.ear/temp
mkdir jarfile
cd $current_path/seurat-web-ci.ear/temp/seurat-web.war
jar -cf ../jarfile/seurat-web.war ./*
cd $current_path/seurat-web-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/domainmodel-project-1.0.0-SNAPSHOT.jar ./*
cd $current_path/seurat-web-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/ios-utilities-1.0.0-SNAPSHOT.jar ./*
cd $current_path/seurat-web-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-automation-1.0.0-SNAPSHOT.jar ./*
cd $current_path/seurat-web-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-initialize-3.3.0-SNAPSHOT.jar ./*
cd $current_path/seurat-web-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-report-1.0.0-SNAPSHOT.jar ./*

cd $current_path/seurat-web-ci.ear


if [ -e seurat-web.war ] 
then  rm -rf seurat-web.war 
fi
cp $current_path/seurat-web-ci.ear/temp/jarfile/seurat-web.war $current_path/seurat-web-ci.ear
cd $current_path/seurat-web-ci.ear/lib
if [ -e domainmodel-project-1.0.0-SNAPSHOT.jar ] 
then  rm -rf domainmodel-project-1.0.0-SNAPSHOT.jar
fi
cp $current_path/seurat-web-ci.ear/temp/jarfile/domainmodel-project-1.0.0-SNAPSHOT.jar $current_path/seurat-web-ci.ear/lib
cd $current_path/seurat-web-ci.ear/lib
if [ -e ios-utilities-1.0.0-SNAPSHOT.jar ] 
then  rm -rf ios-utilities-1.0.0-SNAPSHOT.jar 
fi
cp $current_path/seurat-web-ci.ear/temp/jarfile/ios-utilities-1.0.0-SNAPSHOT.jar $current_path/seurat-web-ci.ear/lib
cd $current_path/seurat-web-ci.ear/lib
if [ -e seurat-automation-1.0.0-SNAPSHOT.jar ] 
then  rm -rf seurat-automation-1.0.0-SNAPSHOT.jar
fi
cp $current_path/seurat-web-ci.ear/temp/jarfile/seurat-automation-1.0.0-SNAPSHOT.jar $current_path/seurat-web-ci.ear/lib
cd $current_path/seurat-web-ci.ear/lib
if [ -e seurat-initialize-3.3.0-SNAPSHOT.jar ] 
then  rm -rf seurat-initialize-3.3.0-SNAPSHOT.jar
fi
cp $current_path/seurat-web-ci.ear/temp/jarfile/seurat-initialize-3.3.0-SNAPSHOT.jar $current_path/seurat-web-ci.ear/lib
cd $current_path/seurat-web-ci.ear/lib
if [ -e seurat-report-1.0.0-SNAPSHOT.jar ] 
then  rm -rf seurat-report-1.0.0-SNAPSHOT.jar
fi
cp $current_path/seurat-web-ci.ear/temp/jarfile/seurat-report-1.0.0-SNAPSHOT.jar $current_path/seurat-web-ci.ear/lib

cd $current_path/seurat-web-ci.ear
rm -rf temp

cd $current_path/earFiles
if [ -e seurat-web-ci.ear ] 
then  rm -rf seurat-web-ci.ear 
fi
cd $current_path/seurat-web-ci.ear
jar -cf ../earFiles/seurat-web-ci.ear ./*

#---------------------------schedule------------------------------------
cd $current_path/job-schedule-ci.ear/temp
mkdir jarfile
cd $current_path/job-schedule-ci.ear/temp/job-schedule.war
jar -cf ../jarfile/job-schedule.war ./*
cd $current_path/job-schedule-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/domainmodel-project-1.0.0-SNAPSHOT.jar ./*
cd $current_path/job-schedule-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/ios-utilities-1.0.0-SNAPSHOT.jar ./*
cd $current_path/job-schedule-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-automation-1.0.0-SNAPSHOT.jar ./*
cd $current_path/job-schedule-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-initialize-3.3.0-SNAPSHOT.jar ./*
cd $current_path/job-schedule-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-report-1.0.0-SNAPSHOT.jar ./*


cd $current_path/job-schedule-ci.ear
if [ -e job-schedule.war ] 
then  rm -rf job-schedule.war
fi
cp $current_path/job-schedule-ci.ear/temp/jarfile/job-schedule.war $current_path/job-schedule-ci.ear
cd $current_path/job-schedule-ci.ear/lib
if [ -e domainmodel-project-1.0.0-SNAPSHOT.jar ] 
then  rm -rf domainmodel-project-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-schedule-ci.ear/temp/jarfile/domainmodel-project-1.0.0-SNAPSHOT.jar $current_path/job-schedule-ci.ear/lib
cd $current_path/job-schedule-ci.ear/lib
if [ -e ios-utilities-1.0.0-SNAPSHOT.jar ] 
then  rm -rf ios-utilities-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-schedule-ci.ear/temp/jarfile/ios-utilities-1.0.0-SNAPSHOT.jar $current_path/job-schedule-ci.ear/lib
cd $current_path/job-schedule-ci.ear/lib
if [ -e seurat-automation-1.0.0-SNAPSHOT.jar ] 
then  rm -rf seurat-automation-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-schedule-ci.ear/temp/jarfile/seurat-automation-1.0.0-SNAPSHOT.jar $current_path/job-schedule-ci.ear/lib
cd $current_path/job-schedule-ci.ear/lib
if [ -e seurat-initialize-3.3.0-SNAPSHOT.jar ] 
then  rm -rf seurat-initialize-3.3.0-SNAPSHOT.jar
fi
cp $current_path/job-schedule-ci.ear/temp/jarfile/seurat-initialize-3.3.0-SNAPSHOT.jar $current_path/job-schedule-ci.ear/lib
cd $current_path/job-schedule-ci.ear/lib
if [ -e seurat-report-1.0.0-SNAPSHOT.jar ] 
then  rm -rf seurat-report-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-schedule-ci.ear/temp/jarfile/seurat-report-1.0.0-SNAPSHOT.jar $current_path/job-schedule-ci.ear/lib
cd $current_path/job-schedule-ci.ear

rm -rf temp

cd $current_path/earFiles
if [ -e job-schedule-ci.ear ] 
then  rm -rf job-schedule-ci.ear
fi
cd $current_path/job-schedule-ci.ear
jar -cf ../earFiles/job-schedule-ci.ear ./*

#---------------------------execution-----------------------------------
cd $current_path/job-execution-ci.ear/temp
mkdir jarfile
cd $current_path/job-execution-ci.ear/temp/job-execution.war
jar -cf ../jarfile/job-execution.war ./*
cd $current_path/job-execution-ci.ear/temp/domainmodel-project-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/domainmodel-project-1.0.0-SNAPSHOT.jar ./*
cd $current_path/job-execution-ci.ear/temp/ios-utilities-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/ios-utilities-1.0.0-SNAPSHOT.jar ./*
cd $current_path/job-execution-ci.ear/temp/seurat-automation-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-automation-1.0.0-SNAPSHOT.jar ./*
cd $current_path/job-execution-ci.ear/temp/seurat-initialize-3.3.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-initialize-3.3.0-SNAPSHOT.jar ./*
cd $current_path/job-execution-ci.ear/temp/seurat-report-1.0.0-SNAPSHOT.jar
jar -cf ../jarfile/seurat-report-1.0.0-SNAPSHOT.jar ./*

cd $current_path/job-execution-ci.ear
if [ -e job-execution.war ] 
then  rm -rf job-execution.war
fi
cp $current_path/job-execution-ci.ear/temp/jarfile/job-execution.war $current_path/job-execution-ci.ear
cd $current_path/job-execution-ci.ear/lib
if [ -e domainmodel-project-1.0.0-SNAPSHOT.jar ] 
then  rm -rf domainmodel-project-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-execution-ci.ear/temp/jarfile/domainmodel-project-1.0.0-SNAPSHOT.jar $current_path/job-execution-ci.ear/lib
cd $current_path/job-execution-ci.ear/lib
if [ -e ios-utilities-1.0.0-SNAPSHOT.jar ] 
then  rm -rf ios-utilities-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-execution-ci.ear/temp/jarfile/ios-utilities-1.0.0-SNAPSHOT.jar $current_path/job-execution-ci.ear/lib
cd $current_path/job-execution-ci.ear/lib
if [ -e seurat-automation-1.0.0-SNAPSHOT.jar ] 
then  rm -rf seurat-automation-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-execution-ci.ear/temp/jarfile/seurat-automation-1.0.0-SNAPSHOT.jar $current_path/job-execution-ci.ear/lib
cd $current_path/job-execution-ci.ear/lib
if [ -e seurat-initialize-3.3.0-SNAPSHOT.jar ] 
then  rm -rf seurat-initialize-3.3.0-SNAPSHOT.jar
fi
cp $current_path/job-execution-ci.ear/temp/jarfile/seurat-initialize-3.3.0-SNAPSHOT.jar $current_path/job-execution-ci.ear/lib
cd $current_path/job-execution-ci.ear/lib
if [ -e seurat-report-1.0.0-SNAPSHOT.jar ] 
then  rm -rf seurat-report-1.0.0-SNAPSHOT.jar
fi
cp $current_path/job-execution-ci.ear/temp/jarfile/seurat-report-1.0.0-SNAPSHOT.jar $current_path/job-execution-ci.ear/lib

cd $current_path/job-execution-ci.ear
rm -rf temp

cd $current_path/earFiles
if [ -e job-execution-ci.ear ] 
then  rm -rf job-execution-ci.ear 
fi
cd $current_path/job-execution-ci.ear
jar -cf ../earFiles/job-execution-ci.ear ./*

#-----delete the ear fold---------------------------------------
rm -rf $current_path/seurat-web-ci.ear
rm -rf $current_path/job-schedule-ci.ear
rm -rf $current_path/job-execution-ci.ear
cd $current_path
if [ -e seurat-web-ci.ear ] 
then  rm -rf seurat-web-ci.ear 
fi
if [ -e job-schedule-ci.ear ] 
then  rm -rf job-schedule-ci.ear
fi
if [ -e job-execution-ci.ear ] 
then  rm -rf job-execution-ci.ear
fi
cd $current_path