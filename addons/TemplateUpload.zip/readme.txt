bo-rpt-uploader.jar是一个上传BO报表模板的小工具。

1. 使用时，先要创建与上传相关的配置信息，包括BO
Server的连接和RPT模板文件位置信息。
具体可以参考BO.conf示例文件，其中bo.crystal.report.root.dir指定是本地模板路径，要求路径中不能带有中文。

2. 运行程序，上传报表模板
在命令行下，执行java -jar bo-rpt-uploader.jar BO.conf
BO.conf为BO配置信息文件，需要作为参数传给程序。可以根据不同的环境和需求，建立多个BO配置信息文件，执行程序要做为参数来指定。

注意：
1. 程序会先删除BO
Server上的ISIS2文件夹下所有的RPT报表模板，再将本地模板路径下的所有报表模板上传到BO
Server上。
2. 访问BO
Server，必须要在本机的hosts文件中，加入BO主机名与IP的对应信息，否则会报无法访问BO


