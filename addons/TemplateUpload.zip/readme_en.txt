1 refer the BO.conf sample file to setup the BO configuration and the RPT template files location. 
2 run the command line to upload the report template
    java -jar bo-rpt-uploader.jar BO.conf 

Be careful：
1 The BO server must be in the work, and the user can login through the CMS console
2 The user need to create a ISIS2 folder in Root folder in advance through the CMS console



